gl.setup(1920, 1080)

function node.render()
    -- Load and render the HTML file
    util.file_watch("html/index.html", function(content)
        node.render = function()
            gl.clear(0, 0, 0, 1)
            local webview = resource.create_webview()
            webview:open(content)
            webview:draw(0, 0, WIDTH, HEIGHT)
        end
    end)
end
